class Settings {
    static randomColors = false;
    static percentOfNumbers = 1.0;
    static speed = 50; // `CollatzNumber.next()` calls per second
    static slideSpeed = 1; // higher = slower
    static lineWidth = 1;
    static showDot = true;
    static dotSize = 0.1;
}