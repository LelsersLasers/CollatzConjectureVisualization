# Collatz Conjecture Visualization

​Customizable visualization of the Collatz conjecture in JavaScript.
Running live on the web at: https://lelserslasers.itch.io/collatz-conjecture

![Showcase](./Showcase/Showcase1.PNG)